# AuraCore Technologies: Linux Essentials Reference Guide

Welcome to the **command line interface**! As an incoming trainee at AuraCore, you will be working with secure operating systems and edge computing infrastructure. Because Linux is **open source** and incredibly stable, it forms the backbone of our IoT servers. 

Transitioning from a graphical user interface (GUI) to a terminal can feel intimidating at first. This cheat sheet is designed to help you navigate your new Windows Subsystem for Linux (WSL) environment with confidence. 

---

## 1. The Directory Structure

Unlike Windows, which uses drive letters like `C:\`, Linux organizes everything under a single unified tree.

*   **The Root Directory (`/`)**: 
    The very top of the Linux file system is called the **root** directory, represented by a forward **slash** (`/`). Everything on your system lives under root. Unless you are an administrator, you generally should not modify files here.
*   **The Home Directory (`~`)**: 
    Represented by the tilde symbol (`~`), this is your personal workspace (usually located at `/home/username/`). All your boot camp projects, datasets, and scripts should be stored here. 

---

## 2. Navigating the File System

When you open your WSL terminal, you are interacting with a specific folder on your computer. These commands help you figure out where you are and how to move around.

### `pwd` (Print Working Directory)
Tells you exactly which directory you are currently in.
```bash
pwd
# Output example: /home/jdoe
```

### `cd` (Change Directory)
Moves you into a different folder.
```bash
cd /var/log      # Moves you to the /var/log directory
cd ~             # Jumps directly back to your home directory
cd ..            # Moves you up one directory level
```

---

## 3. Viewing Files and Directories

The **`ls`** (list) command is the most common tool you will use. It shows you the contents of the directory you are currently in.

### `ls` (Basic List)
Lists the visible files and folders in your current directory.
```bash
ls
```

### `ls -a` (List All / Hidden Files)
In Linux, any file or folder name that starts with a dot (e.g., `.bashrc`) is hidden by default. These are often important configuration files. Use the `-a` flag to reveal them.
```bash
ls -a
```

### `ls -l` (Long Format)
Displays a detailed list of your files, including critical security information such as read, write, and execute permissions, file ownership, file size, and the date it was last modified.
```bash
ls -l
```

*Pro Tip: You can combine flags! Typing `ls -la` will show you a detailed, long-format list that includes hidden files.*

---

## 4. Getting Help

You don't need to memorize every command and flag. The Linux environment comes with built-in documentation.

### `--help` (Quick Syntax Check)
If you know the command you want to use but forgot the exact syntax or flags, append `--help` to the command for a quick, readable summary.
```bash
ls --help
```

### `man` (Manual Pages)
If you need comprehensive, detailed documentation about a command, use the `man` command followed by the tool you want to learn about. This opens the official manual page.
```bash
man ls
```
*(Press `q` to quit the manual and return to your prompt).*

---

**Need further assistance?** 
If you are stuck on a specific error while configuring your WSL environment, please reach out to the Infrastructure team on the `#bootcamp-support` channel. Happy coding!