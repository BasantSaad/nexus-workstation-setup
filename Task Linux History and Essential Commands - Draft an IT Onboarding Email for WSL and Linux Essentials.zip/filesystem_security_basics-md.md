# AuraCore Trainee Guide: File System Security & Best Practices

Welcome to the second part of your foundational onboarding! As you prepare for the AI & Machine Learning Boot Camp, it is crucial to understand how AuraCore secures its operating systems and edge computing infrastructure. Because Linux is **open source** and serves as the backbone for our secure edge devices, it relies on a strict, built-in permission system to keep files safe. 

Here is a quick overview of how to read file permissions and where you should securely store your data.

## 1. Decoding Directory Permissions with `ls`

In a standard graphical environment, you might right-click a file to view its properties. In the **command line interface**, you use commands to achieve the exact same result, but with much more detail and speed.

To view the security permissions of files and directories in your current location, you use the `ls` command combined with the "long format" flag:

```bash
ls -l
```

When you run this command, you will see output that looks something like this:

```text
-rw-r--r-- 1 trainee trainee 4096 Oct 12 10:00 sensor_data.csv
drwxr-xr-x 2 trainee trainee 4096 Oct 12 10:05 models
```

The most important part of this output is the block of 10 characters on the far left. Here is how to interpret those read (`r`), write (`w`), and execute (`x`) rights:

*   **The First Character:** Indicates the file type. A dash (`-`) means it is a regular file. A `d` means it is a directory.
*   **Characters 2-4 (Owner):** Represent the **Owner's** permissions. In the `models` directory example above, `rwx` means you (the owner) can **R**ead, **W**rite (modify), and e**X**ecute files inside it.
*   **Characters 5-7 (Group):** Represent the **Group's** permissions. `r-x` means anyone in your assigned user group can read and execute, but cannot write to the files.
*   **Characters 8-10 (Others):** Represent **Others'** permissions (everyone else on the system). Again, `r-x` means they can only read and execute.

Understanding these flags ensures you always know exactly who has access to your machine learning datasets and training scripts.

## 2. Directory Isolation: Why We Use the `/home` Directory

In Linux, the entire file system is a single hierarchical tree that starts at the very top. This top level is represented by a single forward **slash** (`/`) and is known as the **root** directory. 

As an AuraCore trainee, you have a dedicated, isolated workspace located at `/home/your_username`. 

### Security Guideline: Keep Your Data at Home

You **must** store all sensitive data, IoT datasets, and training models exclusively within your user's `/home` directory, and **never** in the root directory or system-level subdirectories.

**Why is this mandatory?**

1. **Security & Isolation:** Files placed in your `/home` directory automatically inherit proper ownership permissions (as demonstrated in the `ls -l` output). Placing sensitive data outside of this secured boundary strips away these protections and exposes it to unintended access or execution by other system processes.
2. **System Stability:** The system root directory and its sub-folders (like `/bin`, `/etc`, and `/var`) contain critical operating system files. Accidentally saving files, running scripts, or modifying data here could permanently break your WSL environment.

Whenever you open your WSL terminal, you will start in your `/home` directory by default. Keep your files there, practice good permission hygiene, and you will have a rock-solid foundation for the rest of the Boot Camp!