# AuraCore Trainee Guide: File System Security & Best Practices

This is a supplement to your WSL onboarding guide. Because Linux is **open source** and powers AuraCore's secure edge devices, it relies on a strict, built-in permission system to keep files safe. This guide shows you how to read those permissions and where to store your data.

---

## 1. Understanding Directory Permissions with `ls -l`

In a graphical environment you might right-click a file to see its properties. In the **command line interface**, you use the `ls` command with the **long format** flag:

```bash
ls -l
```

Example output:

```text
-rw-r--r-- 1 trainee trainee 4096 Oct 12 10:00 sensor_data.csv
drwxr-xr-x 2 trainee trainee 4096 Oct 12 10:05 models
```

The 10 characters on the far left show who can do what. The three permission types are:

| Symbol | Permission | Meaning |
|--------|-----------|---------|
| `r` | Read | View the contents of a file or list a directory |
| `w` | Write | Modify or delete a file; add or remove files in a directory |
| `x` | Execute | Run a file as a program; enter a directory |
| `-` | None | That permission is not granted |

### How to read the 10 characters

- **Character 1: file type.** `-` is a regular file and `d` is a directory.
- **Characters 2-4: Owner.** In `models` above, `rwx` means the owner can read, write, and execute.
- **Characters 5-7: Group.** `r-x` means group members can read and execute but **cannot write**.
- **Characters 8-10: Others.** `r-x` means everyone else on the system can read and execute but cannot write.

In the example, `sensor_data.csv` is `-rw-r--r--`: the owner can read and write, while the group and others can only read.

> **Tip:** Run `ls -l` often so you always know who has access to your datasets and training scripts. Use `ls -la` to include hidden files.

---

## 2. Security Guideline: Keep Sensitive Data in `/home`

The entire Linux file system is one tree. The top is the **root** directory, written as a single forward **slash** (`/`). Your isolated workspace is `/home/your_username` (shortcut: `~`).

> **Guideline:** You **must** store all sensitive data, IoT datasets, and training models inside your own `/home` directory. **Never** store them in the root directory (`/`) or in system directories such as `/bin`, `/etc`, or `/var`.

### Why this is mandatory

1. **Security and isolation.** Files created in your `/home` directory get the correct ownership and permissions automatically, as shown in the `ls -l` output above. Data placed outside this protected boundary loses those protections and can be accessed or executed by other users and system processes.
2. **System stability.** The root directory and its subfolders hold critical operating system files. Saving files, running scripts, or changing data there can permanently break your WSL environment.
3. **Least privilege.** Working in `/home` means you never need administrator rights for day-to-day work, which reduces the risk of accidental or malicious changes to the system.

### Quick habits

```bash
pwd      # Confirm where you are (should start with /home/your_username)
cd ~     # Jump back to your home directory at any time
ls -l    # Check permissions on your files
```

Your WSL terminal opens in your `/home` directory by default. Keep your files there and practice good permission hygiene, and you will have a strong foundation for the rest of the Boot Camp.
