# Welcome to AuraCore Boot Camp

Welcome to AuraCore Technologies! We are thrilled to have you join our AI & Machine Learning Boot Camp. As you prepare to work with our edge computing infrastructure and IoT devices, we first need to build a rock-solid technical foundation. 

Because AuraCore's secure operating systems are deeply rooted in the **open source** community, much of our server infrastructure is built on Linux. To standardise your training environment on your company-issued laptops, we use the Windows Subsystem for Linux (WSL). This guide will help you confidently transition from a standard graphical user interface to a powerful text-based environment.

## 1. Setting Up Your Command Line Interface (WSL)

To get started, you will need to enable Linux on your Windows machine. Please follow this 3-step configuration checklist to enable and open WSL:

1. **Open PowerShell as Administrator:** Click your Windows Start menu, type `PowerShell`, right-click the Windows PowerShell application, and select "Run as administrator".
2. **Install WSL:** In the PowerShell window, type the following command and press Enter:
   ```bash
   wsl --install
   ```
   *(This command automatically enables the required optional Windows features and installs the default Linux distribution.)*
3. **Launch the Interface:** Restart your laptop to apply the changes. Once logged back in, open your Start menu and search for "Ubuntu" (or simply type `wsl` in a standard terminal window) to launch your new **command line interface**.

## 2. Navigating the File System

Once your terminal is open, you will rely on text commands rather than clicking on folder icons to look around. 

* **Listing Directories:** To see the standard files and folders in your current location, use the `ls` command. 
* **Paths and Structure:** You will quickly notice that Linux uses a forward **slash** (`/`) to separate directories, completely opposite to the backslashes used in Windows. The absolute top of the Linux file system hierarchy is called the **root** directory (represented by a single `/`).
* **Finding Hidden Files:** In Linux, many vital configuration files are hidden by default (indicated by a filename starting with a period, such as `.bashrc`). To reveal hidden files, you must use the `ls -a` syntax. The `-a` flag tells the system to list "all" files, ensuring that no hidden configurations are missed.

```bash
# Standard list of visible files and directories
ls

# List all files, explicitly including hidden configuration files
ls -a
```

## 3. Getting Help: man vs --help

The terminal environment can feel intimidating to beginners, but you are never truly stuck. Linux comes with excellent built-in documentation. When you need assistance with a command, you have two primary methods to get answers immediately:

* **Quick Refresher (`--help`):** If you already know a command but just need a quick reminder of its flags, append `--help` to it. The `--help` flag is used for quick syntax checks and will output a concise summary directly to your screen.
* **Comprehensive Guides (`man`):** If you need deep, thorough explanations, use the `man` command (short for manual). The `man` command is used for detailed manuals. By typing `man` followed by your command, you will enter a dedicated reading view that explains every available option. (Press the `q` key to quit the manual and return to your terminal prompt).

```bash
# Used for quick syntax checks
ls --help

# Used for detailed manuals
man ls
```

***

*Next Steps: Please review the accompanying `security_best_practices.md` document to understand AuraCore's file permission standards and data storage policies.*