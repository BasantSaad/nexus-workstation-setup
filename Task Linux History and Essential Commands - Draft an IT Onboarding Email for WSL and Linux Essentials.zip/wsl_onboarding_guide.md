**Subject:** Welcome to AuraCore Boot Camp: Set Up Your Linux Environment (WSL)

---

# Welcome to AuraCore Boot Camp

Welcome to AuraCore Technologies! We are thrilled to have you join our AI & Machine Learning Boot Camp. Before we start working with our edge computing infrastructure and IoT devices, we need to build a solid technical foundation.

Much of AuraCore's server infrastructure runs on Linux, which is **open source** and known for its stability. To give everyone the same training environment on company-issued laptops, we use the **Windows Subsystem for Linux (WSL)**. This guide will help you move from a graphical interface to a text-based **command line interface** with confidence.

---

## 1. Setting Up Your Command Line Interface (WSL)

Follow this 3-step checklist to enable and open WSL:

1. **Open PowerShell as Administrator.**
   Click the Windows Start menu, type `PowerShell`, right-click **Windows PowerShell**, and select **Run as administrator**.

2. **Install WSL.**
   In the PowerShell window, type the following command and press Enter:

   ```powershell
   wsl --install
   ```

   This enables the required optional Windows features and installs the default Linux distribution (Ubuntu).

3. **Restart and launch.**
   Restart your laptop to apply the changes. When you log back in, search for **Ubuntu** in the Start menu (or type `wsl` in any terminal window) to open your new command line interface.

---

## 2. Navigating the File System

In the terminal you use text commands instead of clicking folder icons.

- **Listing contents:** Use the `ls` command to list the files and folders in your current location.
- **Paths:** Linux separates directories with a forward **slash** (`/`), the opposite of the backslash (`\`) used in Windows. For example: `/home/your_username/projects`.
- **The top of the tree:** The very top of the Linux file system is called the **root** directory and is written as a single `/`.

### Revealing Hidden Files with `ls -a`

Many important configuration files are hidden by default. Their names start with a period, such as `.bashrc`. A plain `ls` will not show them.

To reveal them, add the `-a` flag (short for "all"):

```bash
# Standard list of visible files and directories
ls

# List ALL files, including hidden configuration files
ls -a
```

> **Tip:** You can combine flags. `ls -la` shows hidden files in a detailed long format.

---

## 3. Getting Help: `--help` vs `man`

You are never truly stuck. Linux has built-in documentation, and there are two ways to reach it:

- **`--help` is for quick syntax checks.** Append it to a command for a short summary of its options, printed straight to your screen.
- **`man` is for detailed manuals.** Type `man` followed by a command to open its full manual page, which explains every option. Press `q` to quit and return to your prompt.

```bash
# Quick syntax check
ls --help

# Detailed manual (press q to exit)
man ls
```

---

## Need Help?

If you hit an error while configuring WSL, reach out to the Infrastructure team on the `#bootcamp-support` channel.

**Next step:** Please read the accompanying `security_best_practices.md` to learn AuraCore's file permission standards and data storage policies.

See you at Boot Camp!
