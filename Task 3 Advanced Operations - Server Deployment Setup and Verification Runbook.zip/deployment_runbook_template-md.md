# Server Deployment Setup and Verification Runbook

**Client:** Financial QA Staging
**Prepared For:** Junior Support Engineering Team
**Prepared By:** [Your Name/Title]
**Date:** [Current Date]

## Overview
This runbook details the manual intervention steps required to provision the staging server following the automated provisioning script failure. The commands below must be executed in sequence to secure the environment, clear hung processes, and verify connectivity before the client QA walkthrough.

---

## 1. Account & Group Provisioning

**Objective:** Create the required secondary group (`appgroup`) and the service account (`svc_web`), ensuring the user is appended to the group correctly without altering their primary group.

**Instructions:** 
Provide the `shadow-utils` commands to create the group, create/modify the user, and verify the user creation via `/etc/passwd`.

**Commands:**
```bash
# 1. Create the 'appgroup' group


# 2. Create the 'svc_web' service account


# 3. Append 'appgroup' to 'svc_web' without altering the primary group


# 4. Verify user creation by inspecting /etc/passwd

```

**Explanation:**
[Provide a brief explanation of the flags used in the commands above to ensure secondary group appending is handled safely.]

---

## 2. Directory Permissions Verification

**Objective:** Secure the application directory (`/opt/app`) so that the owner has read/write/execute (7), the group has read/execute (5), and others have no access (0).

**Instructions:**
Provide the exact octal `chmod` command to set the permissions, followed by the `ls` command to verify the resulting permission string.

**Commands:**
```bash
# 1. Configure the directory permissions on /opt/app using octal notation


# 2. Verify the resulting permission string matches requirements

```

**Explanation:**
[Explain how the octal values provided map directly to the read, write, and execute permission bits.]

---

## 3. Process Troubleshooting & Termination

**Objective:** Identify and terminate hung processes or suspended jobs left by the crashed deployment script.

**Instructions:**
Detail the sequence of `procps` commands to find the PID of the stuck processes, check for suspended background jobs, and safely terminate the remnants.

**Commands:**
```bash
# 1. Identify running process IDs related to the failed deployment


# 2. Check for background suspended jobs in the current shell session


# 3. Terminate the stuck zombie process remnants (replace PID with actual process id)

```

**Explanation:**
[Briefly explain the utilities used to locate the processes and the specific kill signals used for termination.]

---

## 4. Network Connectivity Checks

**Objective:** Verify network routing and connectivity from the server's ETH interface to the database IP (`10.0.5.50`), enforcing a strict 4-packet limit to prevent infinite hanging.

**Instructions:**
Construct the `net-tools` or `iputils` terminal command to perform the network ping test.

**Commands:**
```bash
# 1. Verify connectivity to the database IP (10.0.5.50) with a 4-packet limit

```

**Explanation:**
[Explain the flags used to limit the packet count and ensure the test does not hang.]

---

## 5. Application Health Verification

**Objective:** Ensure the application is reporting a healthy status by analyzing the local health check endpoint.

**Instructions:**
Develop a non-interactive Bash one-liner that downloads the webpage payload from `http://localhost:8080/health` and pipes the output into text processing utilities to count the exact frequency of the keyword 'SUCCESS'.

**Commands:**
```bash
# 1. Fetch health payload and count exact frequency of 'SUCCESS'

```

**Explanation:**
[Explain the utilities used in the pipeline (e.g., curl, grep, wc) and how they isolate and count the target keyword.]