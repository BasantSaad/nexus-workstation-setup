# Architecture & Provisioning Specification: Staging Environment

**Company:** NexusGrid IT Services
**Project:** Financial Client QA Walkthrough 
**Document Owner:** Elena Rostova, Lead Systems Architect
**Classification:** Internal / Confidential

---

## 1. Executive Summary
This document outlines the target architectural parameters for the staging server slated for the upcoming financial client QA walkthrough. Due to an unforeseen mid-execution crash in our automated provisioning pipeline, manual intervention is required to complete the setup and sanitize the environment before the walkthrough commences.

---

## 2. Identity and Access Management (IAM)
The application requires a dedicated, non-root service account with specific group memberships to ensure strict least-privilege security boundaries.

*   **Service Account Username:** `svc_web`
*   **Secondary Group Name:** `appgroup`
*   **Objective:** The user `svc_web` must exist and must be appended to the secondary group `appgroup` without altering their primary group assignment. 

---

## 3. Filesystem and Security Parameters
To prevent unauthorized access to the application binaries and configuration files, strict discretionary access controls must be applied to the application root directory.

*   **Application Directory Path:** `/opt/app`
*   **Target Permissions (Octal):** `750`
    *   **Owner:** Read, Write, Execute (7)
    *   **Group:** Read, Execute (5)
    *   **Others:** No access (0)

---

## 4. Known Environment State (Incident Post-Mortem)
**CRITICAL NOTICE:** Because the legacy deployment script failed abruptly, the server is currently in an unstable state.
*   **Hanging Jobs:** Background jobs may be suspended in the terminal session.
*   **Zombie Processes:** The failed script has orphaned child processes, leaving zombie processes lingering in memory.
*   **Required Action:** Operations must manually audit the process table, verify suspended jobs, and terminate these lingering remnants before proceeding with the health checks.

---

## 5. Network and Connectivity
The application relies on backend systems to function correctly. Internal routing must be verified from the staging server's primary ETH interface to the database cluster.

*   **Database Host IP Address:** `10.0.5.50`
*   **Validation Protocol:** ICMP Echo Request (Ping).
*   *Note:* Connectivity tests must be strictly limited in duration to avoid infinite hanging in the event of a routing blackhole.

---

## 6. Application Health Verification
Once the service account is provisioned, permissions are locked down, processes are cleared, and database connectivity is verified, the application must report a healthy state via its local endpoint.

*   **Health Endpoint URL:** `http://localhost:8080/health`
*   **Expected Health Payload Keyword:** `SUCCESS`
*   **Validation Requirement:** The raw HTTP payload must be fetched and parsed to count the exact occurrence frequency of the target keyword to ensure the application subsystem is fully initialized.