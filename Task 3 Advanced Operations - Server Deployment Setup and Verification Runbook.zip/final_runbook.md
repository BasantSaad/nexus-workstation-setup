# Server Deployment Setup and Verification Runbook

**Client:** Financial QA Staging
**Prepared For:** Junior Support Engineering Team
**Prepared By:** Senior Systems Support, NexusGrid IT Services
**Date:** November 16, 2026
**Reference:** `architecture_spec.md` (Owner: Elena Rostova)

## Overview
This runbook details the manual steps required to provision the staging server after the automated provisioning script failed. Execute the sections **in order**. Stop and escalate to Elena Rostova if any step's output does not match the "Expected result".

**Before you start**
- Run as `root` or prefix each command with `sudo`.
- Do not skip Section 3 before Section 5: leftover processes from the crashed script can interfere with the health check.
- Do not guess PIDs. Only use PIDs you read from your own command output.

---

## 1. Account & Group Provisioning

**Objective:** Create group `appgroup` and service account `svc_web`, appending `appgroup` as a *secondary* group without changing the primary group.

**Commands:**
```bash
# 1. Create the 'appgroup' group.
#    groupadd (shadow-utils) creates a new group entry in /etc/group.
groupadd appgroup

# 2. Create the 'svc_web' service account.
#    -r                 : system account (low UID, no aging, no mail spool) suited to service users
#    -s /usr/sbin/nologin : no interactive login shell (least privilege; nobody can log in as this user)
#    No -g/-G here, so the primary group defaults to a new group named 'svc_web'.
#    If the crash already created the user, you will see "user 'svc_web' already exists" - that is OK, continue to step 3.
useradd -r -s /usr/sbin/nologin svc_web

# 3. Append 'appgroup' to 'svc_web' WITHOUT altering the primary group.
#    -G appgroup : sets the supplementary (secondary) group list
#    -a          : APPEND to the existing list. NEVER use -G without -a, it would REPLACE all existing secondary groups.
#    The primary group is controlled by -g (lowercase), which we deliberately do not use.
usermod -aG appgroup svc_web

# 4. Verify user creation by inspecting /etc/passwd.
#    '^svc_web:' anchors the match to the start of the line so similarly named users are not matched.
grep '^svc_web:' /etc/passwd

# 4b. Supplementary check of the group addition.
#     /etc/passwd stores only the PRIMARY group (4th field), so secondary membership will NOT appear there.
id svc_web                # lists uid, primary gid and all groups
getent group appgroup     # the member list at the end of the line should include svc_web
```

**Expected result:**
- `grep` prints a line like `svc_web:x:<UID>:<GID>::/home/svc_web:/usr/sbin/nologin`.
- `id svc_web` shows `gid=<N>(svc_web)` as primary and `appgroup` inside `groups=...`.
- `getent group appgroup` ends in `:svc_web`.

**Explanation:** `-a -G` is the safe combination: `-G` names the supplementary groups and `-a` makes `usermod` append rather than overwrite. Primary group is untouched because `-g` is never passed. `/etc/passwd` confirms the account exists; `id`/`getent` confirm the secondary membership.

---

## 2. Directory Permissions Verification

**Objective:** Set `/opt/app` to owner `rwx` (7), group `r-x` (5), others none (0).

**Commands:**
```bash
# 1. Configure permissions on /opt/app using octal notation.
#    Each octal digit = sum of bits: read=4, write=2, execute=1.
#    7 (owner)  = 4+2+1 = rwx
#    5 (group)  = 4+0+1 = r-x
#    0 (others) = 0+0+0 = ---
chmod 750 /opt/app

# 2. Verify the resulting permission string.
#    -l : long listing format (shows permission string, owner, group)
#    -d : list the directory ITSELF rather than its contents
#    (plain 'ls -l /opt/app' would show the files inside, not the directory's own permissions)
ls -ld /opt/app
```

**Expected result:** the line begins with `drwxr-x---` (`d` = directory, then `rwx`, `r-x`, `---`).

**Explanation:** Each octal digit maps directly to one permission triplet (owner, group, others), with read = 4, write = 2, execute = 1 added together. For directories, execute (`x`) means "may enter/traverse", which is why the group needs 5 (not just 4) to use the app files.

> Note: `chmod` does not change ownership. The spec does not state the owner/group of `/opt/app`. If `ls -ld` shows a group other than `appgroup`, do **not** change it on your own; ask Elena whether `chgrp appgroup /opt/app` is intended, since without it members of `appgroup` will not actually receive the group's `r-x`.

---

## 3. Process Troubleshooting & Termination

**Objective:** Find and clear suspended jobs and zombie remnants left by the crashed deployment script.

> **Zombie processes cannot be killed.** A zombie (state `Z`) is already dead; it only remains in the process table because its *parent* has not collected its exit status. To remove it you must terminate (or fix) the **parent** process, whose PID is shown as `PPID`. Be careful: never kill PID 1 or any process you cannot tie to the failed deployment.

**Commands:**
```bash
# 1a. Identify processes related to the failed deployment.
#     -e : all processes, -o : custom columns (PID, parent PID, state, elapsed time, command).
ps -eo pid,ppid,stat,etime,cmd | head -50

# 1b. List zombies specifically. STAT beginning with 'Z' (shown as <defunct>) means zombie.
#     awk keeps the header line (NR==1) and any row whose 3rd column starts with Z.
ps -eo pid,ppid,stat,cmd | awk 'NR==1 || $3 ~ /^Z/'

# 1c. (Optional) Search for the deployment script by name. Replace 'deploy' with the real script name.
#     pgrep -a : print PID plus full command line; -f : match against the full command line.
pgrep -af deploy

# 2. Check for background suspended jobs in the CURRENT shell session.
#    -l : include PIDs. 'Stopped' = suspended (e.g. via Ctrl+Z); 'Running' = still active in background.
#    Note: 'jobs' only shows jobs started from THIS terminal session.
jobs -l

# 3a. Attempt a GRACEFUL shutdown first with SIGTERM (signal 15).
#     SIGTERM lets the process clean up (close files, remove locks, reap children).
#     Replace <PID> with the actual PID from the output above. For a zombie, use its PARENT's PID (the PPID column).
kill -SIGTERM <PID>          # equivalent to: kill -15 <PID>

# 3b. Wait ~10 seconds, then check whether the process is gone.
#     'ps -p' prints the row if the PID still exists and prints only the header if it is gone.
sleep 10
ps -p <PID> -o pid,ppid,stat,cmd

# 3c. ONLY IF 3b shows the process still alive, FORCE termination with SIGKILL (signal 9).
#     SIGKILL cannot be caught or ignored: no cleanup runs, so use it as a last resort
#     because it may leave lock/temp files behind.
kill -SIGKILL <PID>          # equivalent to: kill -9 <PID>

# 3d. Suspended job from step 2? Terminate it by job number, then resume-to-deliver the signal if needed.
#     A stopped job only acts on SIGTERM after it is continued, so send SIGCONT as well.
kill -SIGTERM %1 && kill -SIGCONT %1     # %1 = job number from 'jobs -l'

# 4. Re-verify that no zombies remain.
ps -eo pid,ppid,stat,cmd | awk 'NR==1 || $3 ~ /^Z/'
```

**Expected result:** The final zombie listing shows only the header line (`PID PPID STAT CMD`), and `jobs -l` prints nothing.

**Explanation:** `ps` and `pgrep` (procps) locate processes and their parents; `jobs` (a Bash built-in) reports suspended work in the current terminal. `kill` sends signals: SIGTERM (15) politely asks the process to exit, while SIGKILL (9) is enforced by the kernel and is used only if the process ignores SIGTERM. If a parent process is killed, its zombie children are re-parented to PID 1, which reaps them automatically.

---

## 4. Network Connectivity Checks

**Objective:** Verify routing from the server's ETH interface to the database host `10.0.5.50`, limited to 4 packets.

**Commands:**
```bash
# 0. (Optional) Confirm the name of the primary Ethernet interface. It may be eth0, ens3, ens160, etc.
#    Substitute the real name in the command below if it is not eth0.
ip -br addr        # or: ifconfig -a  (net-tools)

# 1. Verify connectivity to the database IP with a strict 4-packet limit.
#    -c 4   : send exactly 4 ICMP Echo Requests then exit (prevents endless pinging)
#    -W 2   : wait at most 2 seconds for each reply (avoids long stalls on a blackhole)
#    -w 10  : hard overall deadline of 10 seconds, ping exits no matter what
#    -I eth0: source the packets from the ETH interface (use the real interface name)
ping -c 4 -W 2 -w 10 -I eth0 10.0.5.50
```

**Expected result:** `4 packets transmitted, 4 received, 0% packet loss`. If you see `100% packet loss` or `Destination Host Unreachable`, **stop and escalate**: do not continue to the health check, since the application depends on the database.

**Explanation:** `-c 4` bounds the number of probes, while `-W` and `-w` bound the time, so the test cannot hang on a routing blackhole. `-I` forces traffic out of the specified interface, so the result reflects that interface's routing.

---

## 5. Application Health Verification

**Objective:** Confirm the application reports healthy by counting occurrences of `SUCCESS` in the health payload.

**Commands:**
```bash
# 1. Fetch health payload and count the exact frequency of 'SUCCESS'.
#    curl -s            : silent (no progress bar, so only the payload enters the pipe)
#    --fail             : exit non-zero on HTTP errors (4xx/5xx) instead of piping an error page
#    --max-time 10      : give up after 10s so the check can never hang
#    grep -o 'SUCCESS'  : print EACH match on its own line (-o), so multiple hits on one line count separately
#    wc -l              : count the lines = number of occurrences
curl -s --fail --max-time 10 http://localhost:8080/health | grep -o 'SUCCESS' | wc -l
```

**Expected result:** A number of 1 or higher. `0` means the application is **not** healthy (or the endpoint is unreachable); do not sign off, escalate to Elena Rostova. The spec does not define an exact expected count, so report the number you see.

**Explanation:** `curl` downloads the payload, `grep -o` isolates each case-sensitive occurrence of `SUCCESS` on a separate line (plain `grep -c` would count matching *lines*, undercounting when a line contains it twice), and `wc -l` totals them. The whole pipeline is non-interactive and needs no manual parsing.

---

## Completion Checklist
- [ ] `svc_web` exists and `id svc_web` lists `appgroup` as a secondary group
- [ ] `/opt/app` shows `drwxr-x---`
- [ ] No zombie processes and no suspended jobs remain
- [ ] Ping to `10.0.5.50`: 4 sent, 4 received
- [ ] Health check returns a count of `SUCCESS` of 1 or more
- [ ] Output of each step pasted into `verification_logs.txt` on the staging server
